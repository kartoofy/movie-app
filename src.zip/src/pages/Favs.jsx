import "../css/Favorites.css"

        function Favs() {
            return (
                <div className="favs-empty">
                    <h2>No Favorite Movies Yet</h2>
                    <p>Start adding movies to your favs and they show here</p>
                </div>
            )
        }

        export default Favs