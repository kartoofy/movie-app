import './css/App.css'
import MovieCard from './components/MovieCard.jsx'
import Favs from './pages/Favs.jsx'
import Home from './pages/Home.jsx'
import {Routes,Route} from "react-router-dom"
import NavBar from './components/NavBar';


function App() { //component, always starts with a CAP letter

  return (
    <div>
    <NavBar/>
    <main className='main-content'>
      <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/Favs" element={<Favs/>}/>
      </Routes>
    </main>
    </div>
  )
}


export default App
